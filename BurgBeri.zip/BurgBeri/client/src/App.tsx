import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";
import AdminDashboard from "@/pages/AdminDashboard";
import AdminLogin from "@/pages/AdminLogin";
import NotFound from "@/pages/not-found";

function Router() {
  const [isAdmin, setIsAdmin] = useState(false);

  return (
    <Switch>
      <Route path="/">
        <Home />
      </Route>

      <Route path="/admin/login">
        <AdminLogin onLogin={() => setIsAdmin(true)} />
      </Route>

      <Route path="/admin">
        {isAdmin ? (
          <AdminDashboard onLogout={() => setIsAdmin(false)} />
        ) : (
          <AdminLogin onLogin={() => setIsAdmin(true)} />
        )}
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
