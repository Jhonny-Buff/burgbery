import { ImageWithFallback } from "./ImageWithFallback";

interface HeroProps {
  onNavigate: (page: string) => void;
  heroImageUrl?: string | null;
}

export function Hero({ onNavigate, heroImageUrl }: HeroProps) {
  const defaultHero =
    "https://images.unsplash.com/photo-1651993841930-946a700c1524?auto=format&fit=crop&w=1600&q=80";

  return (
    <div className="relative h-[400px] md:h-[500px] overflow-hidden rounded-2xl md:rounded-3xl mb-8 md:mb-12">
      <ImageWithFallback
        src={heroImageUrl || defaultHero}
        alt="Бургбери баннер"
        className="w-full h-full object-cover"
        data-testid="img-hero"
      />

      <div className="absolute inset-0 bg-black/40" />

      <div className="absolute inset-0 flex items-center">
        <div className="px-6 md:px-12 max-w-3xl space-y-4">
          <h2
            className="text-white text-3xl md:text-5xl mb-4"
            data-testid="text-hero-title"
          >
            Вкус, который вы полюбите
          </h2>
          <p
            className="text-zinc-300 text-base md:text-xl mb-6 md:mb-8"
            data-testid="text-hero-description"
          >
            Бургбери — это качественная еда, приготовленная с любовью. Закажите
            любимые роллы, бургеры и пиццу с быстрой доставкой на дом или в
            офис.
          </p>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate("Меню")}
              className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-3 rounded-full text-base md:text-lg font-medium transition-all"
              data-testid="button-hero-menu"
            >
              Смотреть меню
            </button>
            <button
              onClick={() => onNavigate("Акции")}
              className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white px-6 py-3 rounded-full transition-all text-base md:text-lg border border-white/20"
              data-testid="button-hero-promo"
            >
              Акции
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
