import { Tag, Gift, Percent } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface Promotion {
  id: number;
  title: string;
  description: string | null;
  discountLabel: string | null;
}

export function PromotionsPage() {
  const { data: promotions = [] } = useQuery<Promotion[]>({
    queryKey: ['/api/promotions'],
  });

  const defaultPromotions = [
    {
      id: 1,
      title: 'Скидка 20% на первый заказ',
      description: 'При заказе от 1500 ₽ через мобильное приложение',
      discount: '20%',
      icon: Percent,
    },
    {
      id: 2,
      title: 'Бесплатная доставка',
      description: 'При заказе от 1000 ₽ доставка бесплатно',
      discount: '0 ₽',
      icon: Gift,
    },
    {
      id: 3,
      title: 'Комбо обед',
      description: 'Бургер + картофель + напиток всего за 450 ₽',
      discount: '-30%',
      icon: Tag,
    },
  ];

  const items = promotions.length > 0 ? promotions : defaultPromotions;

  return (
    <div>
      <div className="mb-8 md:mb-12">
        <h2 className="text-white text-3xl md:text-4xl mb-3" data-testid="text-promo-title">Акции</h2>
        <p className="text-zinc-400">Специальные предложения и скидки</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {promotions.map((promo) => {
          const Icon = promo.icon;
          const items = promotions.length > 0 ? promotions : defaultPromotions;

  return (
            <div
              key={promo.id}
              className="bg-gradient-to-br from-orange-600/20 to-orange-900/20 rounded-2xl p-6 md:p-8 border border-orange-600/30 hover:border-orange-500 transition-all"
              data-testid={`card-promo-${promo.id}`}
            >
              <div className="bg-orange-600 w-14 h-14 md:w-16 md:h-16 rounded-full flex items-center justify-center mb-6">
                <Icon className="w-7 h-7 md:w-8 md:h-8 text-white" />
              </div>
              
              <div className="text-orange-500 text-3xl md:text-4xl mb-4">{promo.discount}</div>
              <h3 className="text-white text-lg md:text-xl mb-3">{promo.title}</h3>
              <p className="text-zinc-400">{promo.description}</p>
            </div>
          );
        })}
      </div>

      <div className="mt-12 bg-zinc-900 rounded-2xl p-6 md:p-8 border border-zinc-800">
        <h3 className="text-white text-xl md:text-2xl mb-6">Условия акций</h3>
        <div className="space-y-3 text-zinc-400">
          <p>Акции не суммируются с другими предложениями</p>
          <p>Срок действия акций указан в описании</p>
          <p>Подробности уточняйте у оператора</p>
          <p>Организатор оставляет за собой право изменить условия акций</p>
        </div>
      </div>
    </div>
  );
}
