import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export function AdminBackups() {
  const { toast } = useToast();
  const [isDownloading, setIsDownloading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      const res = await apiRequest('GET', '/api/admin/backup');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `burgbery-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      toast({ title: 'Бэкап скачан' });
    } catch (e) {
      console.error(e);
      toast({ title: 'Ошибка скачивания бэкапа', variant: 'destructive' });
    } finally {
      setIsDownloading(false);
    }
  };

  const handleUpload = async (file: File | null) => {
    if (!file) return;
    setIsUploading(true);
    try {
      const text = await file.text();
      const json = JSON.parse(text);
      await apiRequest('POST', '/api/admin/restore', json);
      toast({ title: 'Бэкап загружен и применен' });
    } catch (e) {
      console.error(e);
      toast({ title: 'Ошибка загрузки бэкапа', variant: 'destructive' });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-white text-2xl">Бэкапы базы данных</h2>
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-white">Управление бэкапами</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <Button
              onClick={handleDownload}
              disabled={isDownloading}
              className="bg-orange-600 hover:bg-orange-700 w-full md:w-auto"
            >
              {isDownloading ? 'Скачивание...' : 'Скачать бэкап'}
            </Button>
            <div className="flex-1">
              <Input
                type="file"
                accept="application/json"
                onChange={(e) => handleUpload(e.target.files?.[0] || null)}
                className="bg-zinc-800 border-zinc-700 text-white"
              />
              {isUploading && (
                <p className="text-xs text-zinc-400 mt-1">Загрузка и применение бэкапа...</p>
              )}
            </div>
          </div>
          <p className="text-xs text-zinc-500">
            Бэкап представляет собой JSON-файл со всеми категориями, товарами, клиентами, заказами и промокодами.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
